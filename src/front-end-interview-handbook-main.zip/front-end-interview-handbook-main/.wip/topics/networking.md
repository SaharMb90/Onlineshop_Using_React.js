# Networking

WIP.

## Glossary

- **JSON**
- **RPC**
- **HTTP**
- **HTTP/2**

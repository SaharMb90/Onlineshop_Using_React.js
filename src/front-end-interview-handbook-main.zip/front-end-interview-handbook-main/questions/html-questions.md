# HTML Questions

Moved to [new location](https://www.frontendinterviewhandbook.com/html-questions/).
